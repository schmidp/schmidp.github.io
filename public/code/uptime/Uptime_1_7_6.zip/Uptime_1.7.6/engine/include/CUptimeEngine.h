// CUptimeEngine.h
//
// Copyright (c) 2003 Philipp Markus Alexander Schmid All rights reserved.
//

#ifndef __CUPTIMEENGINE_H
#define __CUPTIMEENGINE_H


#include <e32std.h>
#include <e32def.h>
#include <e32base.h>
#include <w32std.h>
#include <eikenv.h>
#include <MdaAudioSamplePlayer.h>


class TUptimePreferences
{
	public:
		TBuf<KMaxFileName> iFlipOpenSoundFile;
		TBuf<KMaxFileName> iFlipCloseSoundFile;
		int iVolume;
		TBool iPlayOpenSoundState;
		TBool iPlayCloseSoundState;
};

class CUptimeEngine : public CBase, public MMdaAudioPlayerCallback
{
	public:
		IMPORT_C ~CUptimeEngine();
		IMPORT_C static CUptimeEngine* NewL();
		IMPORT_C static CUptimeEngine* NewLC();

		IMPORT_C TDateTime StartupTime();

		IMPORT_C TInt Days();
		IMPORT_C TInt Hours();
		IMPORT_C TInt Minutes();
		IMPORT_C TInt Seconds();

		IMPORT_C void SetPlayOpenSoundState(TBool aState);
		IMPORT_C void SetPlayCloseSoundState(TBool aState);
		IMPORT_C TBool PlayOpenSoundState();
		IMPORT_C TBool PlayCloseSoundState();

		IMPORT_C void PlayFlipOpenSound();
		IMPORT_C void PlayFlipCloseSound();
		
		IMPORT_C void SetFlipOpenSound(TBuf<KMaxFileName>  aFileName);
		IMPORT_C void SetFlipCloseSound(TBuf<KMaxFileName>  aFileName);
		IMPORT_C TBuf<KMaxFileName> FlipOpenSound();
		IMPORT_C TBuf<KMaxFileName> FlipCloseSound();
		
		IMPORT_C void SetVolume(int aVolume);
		IMPORT_C int Volume();

		IMPORT_C void SaveSettings();

    private:
		CUptimeEngine();
		void ConstructL();
		void CalculateUptime(int& days, int& hours, int& minutes, int& seconds);

		// for sound playing
		void MapcInitComplete(TInt aError, const TTimeIntervalMicroSeconds& aDuration);
		void MapcPlayComplete(TInt aError);
		void PlayCleanup();

		void ReadPreferencesL();
		void WritePreferencesL(const TUptimePreferences& aUptimePreferences);
		void DefaultPreferences();

	private:
		TTime* iStartupTime;
		CMdaAudioPlayerUtility* iAudioPlayUtility;

		TUptimePreferences iUptimePreferences;
};

#endif