// CUptimeEngine.cpp
//
// Copyright (c) 2003 Philipp Markus Alexander Schmid All rights reserved.
//

#include "CUptimeEngine.h"

#include <s32file.h>


// requirement for E32 DLLs
EXPORT_C TInt E32Dll(TDllReason)
{
	return 0;
}

EXPORT_C TDateTime CUptimeEngine::StartupTime()
{
	TDateTime startupTime = iStartupTime->DateTime();
	startupTime.SetDay(startupTime.Day()+1);
	return startupTime;
}

EXPORT_C TInt CUptimeEngine::Days()
{
	int days, hours, minutes, seconds;
	CalculateUptime(days, hours, minutes, seconds);
	return days;
}

EXPORT_C TInt CUptimeEngine::Hours()
{
	int days, hours, minutes, seconds;
	CalculateUptime(days, hours, minutes, seconds);
	return hours;
}

EXPORT_C TInt CUptimeEngine::Minutes()
{
	int days, hours, minutes, seconds;
	CalculateUptime(days, hours, minutes, seconds);
	return minutes;
}

EXPORT_C TInt CUptimeEngine::Seconds()
{
	int days, hours, minutes, seconds;
	CalculateUptime(days, hours, minutes, seconds);
	return seconds;
}

EXPORT_C void CUptimeEngine::SetPlayOpenSoundState(TBool aState)
{
	iUptimePreferences.iPlayOpenSoundState = aState;
}

EXPORT_C void CUptimeEngine::SetPlayCloseSoundState(TBool aState)
{
	iUptimePreferences.iPlayCloseSoundState = aState;
}

EXPORT_C TBool CUptimeEngine::PlayOpenSoundState()
{
	return iUptimePreferences.iPlayOpenSoundState;
}

EXPORT_C TBool CUptimeEngine::PlayCloseSoundState()
{
	return iUptimePreferences.iPlayCloseSoundState;
}



CUptimeEngine::CUptimeEngine(){}



EXPORT_C CUptimeEngine::~CUptimeEngine()
{
	delete iStartupTime;
}

EXPORT_C CUptimeEngine* CUptimeEngine::NewL()
{
	CUptimeEngine* self = NewLC();
	CleanupStack::Pop();
	return self;
}

EXPORT_C CUptimeEngine* CUptimeEngine::NewLC()
{
	CUptimeEngine* self = new (ELeave) CUptimeEngine();
	CleanupStack::PushL(self);
	self->ConstructL();
	return self;
}


EXPORT_C void CUptimeEngine::PlayFlipOpenSound()
{
	iAudioPlayUtility = CMdaAudioPlayerUtility::NewFilePlayerL(iUptimePreferences.iFlipOpenSoundFile, *this);
}

EXPORT_C void CUptimeEngine::PlayFlipCloseSound()
{
	iAudioPlayUtility = CMdaAudioPlayerUtility::NewFilePlayerL(iUptimePreferences.iFlipCloseSoundFile, *this);
}

EXPORT_C void CUptimeEngine::SetFlipOpenSound(TBuf<KMaxFileName> aFileName)
{
	iUptimePreferences.iFlipOpenSoundFile = aFileName;
}

EXPORT_C void CUptimeEngine::SetFlipCloseSound(TBuf<KMaxFileName> aFileName)
{
	iUptimePreferences.iFlipCloseSoundFile = aFileName;
}

EXPORT_C TBuf<KMaxFileName> CUptimeEngine::FlipOpenSound()
{
	return iUptimePreferences.iFlipOpenSoundFile;
}

EXPORT_C TBuf<KMaxFileName> CUptimeEngine::FlipCloseSound()
{
	return iUptimePreferences.iFlipCloseSoundFile;
}

EXPORT_C void CUptimeEngine::SetVolume(int aVolume)
{
	iUptimePreferences.iVolume = 10-aVolume+1;
}

EXPORT_C int CUptimeEngine::Volume()
{
	return 10-iUptimePreferences.iVolume+1;
}

EXPORT_C void CUptimeEngine::SaveSettings()
{
	WritePreferencesL(iUptimePreferences);
}

void CUptimeEngine::ConstructL()
{
	TTime now;
	TInt64 startupTimeMicroSeconds = 0x0000000000000000;
	TTimeIntervalMicroSeconds32 tickPeriod;

	UserHal::TickPeriod(tickPeriod);
	startupTimeMicroSeconds = (TInt64) tickPeriod.Int();
	startupTimeMicroSeconds = startupTimeMicroSeconds * User::TickCount();
	now.HomeTime();
	startupTimeMicroSeconds = now.Int64() - startupTimeMicroSeconds;

	iStartupTime = new TTime(startupTimeMicroSeconds);

	DefaultPreferences();
	ReadPreferencesL();
}


void CUptimeEngine::CalculateUptime(int& days, int& hours, int& minutes, int& seconds)
{
	days = 0;
	hours = 0;
	minutes = 0;
	seconds = 0;

	TTime now;
	now.HomeTime();

	TTimeIntervalSeconds uptimeSecondsInterval;
	now.SecondsFrom(*iStartupTime, uptimeSecondsInterval);

	int uptimeSeconds = uptimeSecondsInterval.Int();
	int uptimeMinutes = uptimeSeconds/60;
	int uptimeHours = uptimeMinutes/60;
	days = uptimeHours/24;

	hours = uptimeHours-(days*24);
	minutes = uptimeMinutes-((hours*60)+(days*24*60));
	seconds = uptimeSeconds-((minutes*60)+(hours*60*60)+(days*24*60*60));
}

void CUptimeEngine::MapcInitComplete(TInt aError, const TTimeIntervalMicroSeconds& aDuration)
{
	if (aError)
		PlayCleanup();
	else
	{
		iAudioPlayUtility->SetVolume(iAudioPlayUtility->MaxVolume()/iUptimePreferences.iVolume);
		iAudioPlayUtility->Play();		
	}
}

void CUptimeEngine::MapcPlayComplete(TInt aError)
{
	PlayCleanup();
}

void CUptimeEngine::PlayCleanup()
{
	delete iAudioPlayUtility;
	iAudioPlayUtility = NULL;
}



void CUptimeEngine::ReadPreferencesL()
{
	RFile	file;
	TInt err = file.Open(CEikonEnv::Static()->FsSession(), _L("c:\\system\\apps\\uptime\\uptime.ini"), EFileRead);

	if (err != KErrNone)
		err = file.Open(CEikonEnv::Static()->FsSession(), _L("d:\\system\\apps\\uptime\\uptime.ini"), EFileRead);

	if (err == KErrNone)
	{
		TInt	version;
		TPckg<TInt>	versionPkg(version);
		err = file.Read(versionPkg);
		if (err == KErrNone)
		{
			if (version == 1)
			{
				TPckg<TUptimePreferences>	optionsPkg(iUptimePreferences);
				err = file.Read(optionsPkg);
			}
		}
		file.Close();
	}
}

void CUptimeEngine::WritePreferencesL(const TUptimePreferences& aUptimePreferences)
{
	RFile	file;
	TInt err = file.Replace(CEikonEnv::Static()->FsSession(), _L("c:\\system\\apps\\uptime\\uptime.ini"), EFileRead);
	
	if (err != KErrNone)
		err = file.Replace(CEikonEnv::Static()->FsSession(), _L("d:\\system\\apps\\uptime\\uptime.ini"), EFileRead);

	if (err != KErrNone)
		err = file.Create(CEikonEnv::Static()->FsSession(), _L("c:\\system\\apps\\uptime\\uptime.ini"), EFileRead);

	if (err != KErrNone)
		err = file.Create(CEikonEnv::Static()->FsSession(), _L("d:\\system\\apps\\uptime\\uptime.ini"), EFileRead);

	if (err == KErrNone)
	{
		TInt	version = 1;
		TPckg<TInt>	versionPkg(version);
		err = file.Write(versionPkg);
		if (err == KErrNone)
		{
			TPckg<TUptimePreferences> optionsPkg(aUptimePreferences);
			err = file.Write(optionsPkg);
			file.Close();
		}
	}

	if (err == KErrNone)
	{
		iUptimePreferences = aUptimePreferences;
		User::InfoPrint(_L("Settings saved"));
	}
	else
		User::InfoPrint(_L("Could not save settings"));
}

void CUptimeEngine:: DefaultPreferences()
{	
	/* set default values */
	iUptimePreferences.iFlipOpenSoundFile = _L("c:\\documents\\media files\\audio\\default.wav");
	iUptimePreferences.iFlipCloseSoundFile = _L("c:\\documents\\media files\\audio\\default.wav");
	iUptimePreferences.iVolume = 1;
	iUptimePreferences.iPlayOpenSoundState = 0;
	iUptimePreferences.iPlayCloseSoundState = 0;
}