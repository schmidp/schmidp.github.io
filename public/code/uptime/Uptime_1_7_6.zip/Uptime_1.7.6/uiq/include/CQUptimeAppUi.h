// CQUptimeAppUi.h
//
// Copyright (c) 2003 Philipp Markus Alexander Schmid All rights reserved.
//

#ifndef __CQUPTIMEAPPUI_H
#define __CQUPTIMEAPPUI_H


#include "CQUptime.h"
#include "CUptimeAppView.h"

class CQUptimeAppUi : public CQikAppUi
{
	public:
		void ConstructL();
		~CQUptimeAppUi();
		void HandleScreenDeviceChangedL();
	
	private:
		void CmdAboutL();
		void CmdPreferencesL();

	private:
		void HandleCommandL(TInt aCommand);
	
	private:
		CUptimeAppView* iAppView;
		CUptimeEngine* iModel;
};


#endif