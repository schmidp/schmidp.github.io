// CUptimeDialogPreferences.h
//
// Copyright (c) 2003 Philipp Markus Alexander Schmid All rights reserved.
//

#ifndef __CUPTIMEDIALOGPREFERENCES_H__
#define __CUPTIMEDIALOGPREFERENCES_H__

#include "CQUptime.h"

#include "eikdialg.h"


class CUptimeDialogPreferences : public CEikDialog
{
	public:
		enum TState {EClear, ESet, EIndeterminate};

	public:
		CUptimeDialogPreferences(CUptimeEngine* aModel);
		~CUptimeDialogPreferences();
			
		TBool OkToExitL(TInt aKeycode);

	private:
		virtual void PreLayoutDynInitL();

	private:
		CUptimeEngine* iModel;
};


#endif