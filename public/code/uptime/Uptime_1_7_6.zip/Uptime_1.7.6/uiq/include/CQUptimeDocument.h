// CQUptimeDocument.h
//
// Copyright (c) 2003 Philipp Markus Alexander Schmid All rights reserved.
//

#ifndef __CQUPTIMEDOCUMENT_H
#define __CQUPTIMEDOCUMENT_H


#include "CQUptime.h"
#include "CQUptimeAppUi.h"


class CQUptimeDocument : public CQikDocument
{
	public:
		// construct/destruct
		CQUptimeDocument(CEikApplication& aApp);
		~CQUptimeDocument();
		static CQUptimeDocument* NewL(CEikApplication& aApp);
		void ConstructL();
		CUptimeEngine* Model() {return iModel;}

	private: // from CEikDocument
		CEikAppUi* CreateAppUiL();
		CUptimeEngine* iModel;
};


#endif