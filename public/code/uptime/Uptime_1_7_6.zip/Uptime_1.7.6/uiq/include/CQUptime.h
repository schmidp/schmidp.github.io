// CQUptime.h
//
// Copyright (c) 2003 Philipp Markus Alexander Schmid All rights reserved.
//


#ifndef __CQUPTIME_H
#define __CQUPTIME_H

#include <qikdocument.h>
#include <qikapplication.h>
#include <qikappui.h>

#include <Uptime.rsg>
#include "Uptime.hrh"
#include "CUptimeEngine.h"
    

const TUid KUidUptime = { 0x101F98BC };


class CQUptimeApplication : public CQikApplication
{
		private: // from CApaApplication
			CApaDocument* CreateDocumentL();
			TUid AppDllUid() const;
};


#endif