// CUptimeAppView.h
//
// Copyright (c) 2003 Philipp Markus Alexander Schmid All rights reserved.
//

#ifndef __CUPTIMEAPPVIEW_H
#define __CUPTIMEAPPVIEW_H


#include "CQUptime.h"


class CUptimeAppView : public CCoeControl
{
	public:
		static CUptimeAppView* NewL(const TRect& aRect, CUptimeEngine* aModel);
		static CUptimeAppView* NewLC(const TRect& aRect, CUptimeEngine* aModel);
		void ConstructL(const TRect& aRect, CUptimeEngine* aModel);

		void ToggleRefresh();
		static TInt Tick(TAny* aObject);

		~CUptimeAppView();
	
	private:
		void StartTimer();
		void StopTimer();
		void Draw(const TRect& aRect) const;
		void ReDraw();

	private:
		CPeriodic* iPeriodic;
		CUptimeEngine *iModel;
		int iToggle;
};


#endif