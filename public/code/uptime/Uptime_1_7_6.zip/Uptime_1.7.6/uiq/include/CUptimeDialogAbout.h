// CUptimeDialogAbout.h
//
// Copyright (c) 2003 Philipp Markus Alexander Schmid All rights reserved.
//

#ifndef __CUPTIMEDIALOGABOUT_H__
#define __CUPTIMEDIALOGABOUT_H__


#include "eikdialg.h"


class CUptimeDialogAbout : public CEikDialog
{
	private:
		virtual void PreLayoutDynInitL();
};


#endif