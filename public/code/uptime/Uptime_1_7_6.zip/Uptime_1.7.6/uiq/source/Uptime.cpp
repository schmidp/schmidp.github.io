// Uptime.cpp
//
// Copyright (c) 2003 Philipp Markus Alexander Schmid All rights reserved.
//

#include "CQUptime.h"
#include "CQUptimeDocument.h"


//
// EXPORTed functions
//


EXPORT_C CApaApplication* NewApplication()
{
	return new CQUptimeApplication;
}


GLDEF_C TInt E32Dll(TDllReason)
{
	return KErrNone;
}
