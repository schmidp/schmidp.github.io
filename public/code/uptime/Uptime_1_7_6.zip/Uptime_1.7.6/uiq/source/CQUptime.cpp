// CQUptime.cpp
//
// Copyright (c) 2003 Philipp Markus Alexander Schmid All rights reserved.
//

#include "CQUptime.h"
#include "CQUptimeDocument.h"


TUid CQUptimeApplication::AppDllUid() const
{
	return KUidUptime;
}
    

CApaDocument* CQUptimeApplication::CreateDocumentL()
{
	// Construct the document using its NewL() function, rather 
	// than using new(ELeave), because it requires two-phase
	// construction.
	return CQUptimeDocument::NewL(*this);
}