// CUptimeDialogPreferences.cpp
//
// Copyright (c) 2003 Philipp Markus Alexander Schmid All rights reserved.
//

#include <coemain.h>
#include <eiklabel.h>
#include <eikchkbx.h>
#include <qikslider.h>
#include <qiksoundselector.h>
#include <Uptime.rsg>
#include "Uptime.hrh"
#include "CUptimeDialogPreferences.h"

CUptimeDialogPreferences::CUptimeDialogPreferences(CUptimeEngine* aModel)
{
	iModel = aModel;
}

CUptimeDialogPreferences::~CUptimeDialogPreferences()
{
	iModel = NULL;
}

TBool CUptimeDialogPreferences::OkToExitL(TInt aKeycode)
{
	CCoeControl* volumeControlPtr = this->Control(EPreferencesDialogControlVolume);
	CQikSlider* volumeSlider = static_cast<CQikSlider*>(volumeControlPtr);
	iModel->SetVolume(volumeSlider->CurrentValue());

	CCoeControl* playOpenSoundControlPtr = this->Control(EPreferencesDialogControlPlayOpenSound);
	CEikCheckBox* playOpenSoundCheckBox = static_cast<CEikCheckBox*>(playOpenSoundControlPtr);
	if(playOpenSoundCheckBox->State() == CEikCheckBox::EClear)
	{
		iModel->SetPlayOpenSoundState(0);
	}
	if(playOpenSoundCheckBox->State() == CEikCheckBox::ESet)
	{
		iModel->SetPlayOpenSoundState(1);
	}
	
	CCoeControl* playCloseSoundControlPtr = this->Control(EPreferencesDialogControlPlayCloseSound);
	CEikCheckBox* playCloseSoundCheckBox = static_cast<CEikCheckBox*>(playCloseSoundControlPtr);
	if(playCloseSoundCheckBox->State() == CEikCheckBox::EClear)
	{
		iModel->SetPlayCloseSoundState(0);
	}
	if(playCloseSoundCheckBox->State() == CEikCheckBox::ESet)
	{
		iModel->SetPlayCloseSoundState(1);
	}
	
	CCoeControl* openSoundControlPtr = this->Control(EPreferencesDialogControlOpenSound);
	CQikSoundSelector* openSoundSelector = static_cast<CQikSoundSelector*>(openSoundControlPtr);

	CCoeControl* closeSoundControlPtr = this->Control(EPreferencesDialogControlCloseSound);
	CQikSoundSelector* closeSoundSelector = static_cast<CQikSoundSelector*>(closeSoundControlPtr);

	TBuf<KMaxFileName> tmpFilename;
	openSoundSelector->GetSound(tmpFilename);
	iModel->SetFlipOpenSound(tmpFilename);

	closeSoundSelector->GetSound(tmpFilename);
	iModel->SetFlipCloseSound(tmpFilename);

	iModel->SaveSettings();

	return ETrue;
}

void CUptimeDialogPreferences::PreLayoutDynInitL()
{
	CCoeControl* volumeControlPtr = this->Control(EPreferencesDialogControlVolume);
	CQikSlider* volumeSlider = static_cast<CQikSlider*>(volumeControlPtr);

	volumeSlider->SetValue(iModel->Volume()); 
	volumeSlider->SetNumberOfMarkersL(10);

	CCoeControl* playOpenSoundControlPtr = this->Control(EPreferencesDialogControlPlayOpenSound);
	CEikCheckBox* playOpenSoundCheckBox = static_cast<CEikCheckBox*>(playOpenSoundControlPtr);
	if(iModel->PlayOpenSoundState() == 0)
	{
		playOpenSoundCheckBox->SetState(CEikCheckBox::EClear);
	}
	if(iModel->PlayOpenSoundState() == 1)
	{
		playOpenSoundCheckBox->SetState(CEikCheckBox::ESet);
	}


	CCoeControl* playCloseSoundControlPtr = this->Control(EPreferencesDialogControlPlayCloseSound);
	CEikCheckBox* playCloseSoundCheckBox = static_cast<CEikCheckBox*>(playCloseSoundControlPtr);
	if(iModel->PlayCloseSoundState() == 0)
	{
		playCloseSoundCheckBox->SetState(CEikCheckBox::EClear);
	}
	if(iModel->PlayCloseSoundState() == 1)
	{
		playCloseSoundCheckBox->SetState(CEikCheckBox::ESet);
	}

	CCoeControl* openSoundControlPtr = this->Control(EPreferencesDialogControlOpenSound);
	CQikSoundSelector* openSoundSelector = static_cast<CQikSoundSelector*>(openSoundControlPtr);
	openSoundSelector->SetSound(iModel->FlipOpenSound());

	CCoeControl* closeSoundControlPtr = this->Control(EPreferencesDialogControlCloseSound);
	CQikSoundSelector* closeSoundSelector = static_cast<CQikSoundSelector*>(closeSoundControlPtr);
	closeSoundSelector->SetSound(iModel->FlipCloseSound());
}

