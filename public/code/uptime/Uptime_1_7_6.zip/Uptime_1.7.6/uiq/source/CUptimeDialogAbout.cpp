// CUptimeDialogAbout.cpp
//
// Copyright (c) 2003 Philipp Markus Alexander Schmid All rights reserved.
//

#include <coemain.h>
#include <eiklabel.h>
#include <Uptime.rsg>
#include "Uptime.hrh"
#include "CUptimeDialogAbout.h"


//from CEikDialog
void CUptimeDialogAbout::PreLayoutDynInitL()
{
	HBufC* buf = iCoeEnv->AllocReadResourceLC(R_AUTHOR);
	CEikLabel* label=(CEikLabel*)Control(EAboutDialogControlLabelAuthor);
	label->SetTextL(*buf);
	label->DrawNow();
	CleanupStack::PopAndDestroy(); //buf


	buf = iCoeEnv->AllocReadResourceLC(R_CREATED);
	label=(CEikLabel*)Control(EAboutDialogControlLabelCreated);
	label->SetTextL(*buf);
	label->DrawNow();
	CleanupStack::PopAndDestroy(); //buf


	buf = iCoeEnv->AllocReadResourceLC(R_COPYRIGHT);
	label=(CEikLabel*)Control(EAboutDialogControlLabelCopyright);
	label->SetTextL(*buf);
	label->DrawNow();
	CleanupStack::PopAndDestroy(); //buf


	buf = iCoeEnv->AllocReadResourceLC(R_VERSION);
	label=(CEikLabel*)Control(EAboutDialogControlLabelVersion);
	label->SetTextL(*buf);
	label->DrawNow();
	CleanupStack::PopAndDestroy(); //buf
}