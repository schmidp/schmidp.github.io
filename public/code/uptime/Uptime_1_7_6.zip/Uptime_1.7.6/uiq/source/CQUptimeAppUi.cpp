// CQUptimeAppUi.cpp
//
// Copyright (c) 2003 Philipp Markus Alexander Schmid All rights reserved.
//

#include "CQUptimeAppUi.h"
#include "CQUptimeDocument.h"
#include "CUptimeDialogAbout.h"
#include "CUptimeDialogPreferences.h"

#include <qikhelplauncher.h>


void CQUptimeAppUi::ConstructL()
{
	BaseConstructL();
	iModel = ((CQUptimeDocument*)iDocument)->Model();
	iAppView = CUptimeAppView::NewL(ClientRect(), iModel);
	iAppView->ToggleRefresh();
	iCoeEnv->RootWin().EnableScreenChangeEvents();
}


CQUptimeAppUi::~CQUptimeAppUi()
{
	delete iAppView;
}


void CQUptimeAppUi::HandleCommandL(TInt aCommand)
{
	switch (aCommand)
	{
		case EEikCmdExit:
		{
			Exit();
			break;
		}
		case EUptimeAbout:
		{
			CmdAboutL();
			break;
		}
		case EUptimePreferences:
		{
			CmdPreferencesL();
			break;
		}
		case EUptimeHelp:
		{
			CQikHelpLauncher::LaunchLD(this);
			break;
		}
		case EToggleRefresh:
		{
			iAppView->ToggleRefresh();
			break;
		}
	}
}


void CQUptimeAppUi::CmdPreferencesL()
	{
	if(iAppView == NULL) // if attempt to fire up dialog while application is still loading
		return;

	CEikDialog* preferencesDialog = new(ELeave) CUptimeDialogPreferences(iModel);
	preferencesDialog->ExecuteLD(R_UPTIME_DIALOG_PREFERENCES);
}

void CQUptimeAppUi::CmdAboutL()
	{
	if(iAppView == NULL) // if attempt to fire up dialog while application is still loading
		return;

	CEikDialog* aboutDialog = new(ELeave) CUptimeDialogAbout();
	aboutDialog->ExecuteLD(R_UPTIME_DIALOG_ABOUT);
}

void CQUptimeAppUi::HandleScreenDeviceChangedL()
{
	// flipStatus == 0 -> Open
	// flipStatus == 1 -> Closed
	TBool flipStatus = iCoeEnv->ScreenDevice()->CurrentScreenMode();

	if(flipStatus == 0 && iModel->PlayOpenSoundState() == 1)
	{
		iModel->PlayFlipOpenSound();
	}
	if(flipStatus == 1 && iModel->PlayCloseSoundState() == 1)
	{
		iModel->PlayFlipCloseSound();
	}
}