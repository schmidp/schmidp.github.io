// CUptimeAppView.cpp
//
// Copyright (c) 2003 Philipp Markus Alexander Schmid All rights reserved.
//

#include "CUptimeAppView.h"


CUptimeAppView* CUptimeAppView::NewL(const TRect& aRect, CUptimeEngine* aModel)
{
	CUptimeAppView* self = NewLC(aRect, aModel);
	CleanupStack::Pop();
	return self;
}

CUptimeAppView* CUptimeAppView::NewLC(const TRect& aRect, CUptimeEngine* aModel)
{
	CUptimeAppView* self = new (ELeave) CUptimeAppView();
	CleanupStack::PushL(self);
	self->ConstructL(aRect, aModel);
	return self;
}

void CUptimeAppView::ConstructL(const TRect& aRect, CUptimeEngine* aModel)
{
	iPeriodic=CPeriodic::NewL(0); // neutral priority
	iToggle = 0;
	iModel = aModel;
	CreateWindowL();
	SetRect(aRect);
	ActivateL();
}

TInt CUptimeAppView::Tick(TAny* aObject)
{
	// cast, and call non-static function
	((CUptimeAppView*)aObject)->ReDraw();
	return 1;
}

void CUptimeAppView::StartTimer()
{
	const TInt tickInterval=1000000;
	iPeriodic->Start(TTimeIntervalMicroSeconds32(tickInterval), TTimeIntervalMicroSeconds32(tickInterval), TCallBack(Tick, this));
}

void CUptimeAppView::StopTimer()
{
	iPeriodic->Cancel();
}

CUptimeAppView::~CUptimeAppView()
{
	iPeriodic->Cancel();
	delete iPeriodic;
}

void CUptimeAppView::ToggleRefresh()
{
	if (iToggle == 0)
	{
		iToggle = 1;
		StartTimer();
	}
	else
	{
		iToggle = 0;
		StopTimer();
	}
}

void CUptimeAppView::ReDraw()
{
	// thanks to Jari Laaksonen who found a memory leak in this function
	TRect updateRect(Rect().iTl, Rect().iBr);
	updateRect.Resize(0,-129);
	updateRect.Move(0,129);
	updateRect.Resize(0,(updateRect.Height()-16)*(-1));

	Window().Invalidate(updateRect);
	ActivateGc();
	Window().BeginRedraw(updateRect);
	Draw(Rect());
	Window().EndRedraw();
	DeactivateGc();
}

void CUptimeAppView::Draw(const TRect& aRect) const
{
	///////////////////////////////////////////////////////////////
	///// Double Buffering

	TRect rect = static_cast<CEikAppUi*>(iEikonEnv->AppUi())->ClientRect();

	// create a bitmap to be used off-screen
	CFbsBitmap* offScreenBitmap = new (ELeave) CFbsBitmap();
	User::LeaveIfError(offScreenBitmap->Create(rect.Size(),EColor4K));
	CleanupStack::PushL(offScreenBitmap);

	// create an off-screen device and context
	CFbsBitGc* bitmapContext=NULL;
	CFbsBitmapDevice* bitmapDevice = CFbsBitmapDevice::NewL(offScreenBitmap);
	CleanupStack::PushL(bitmapDevice);
	User::LeaveIfError(bitmapDevice->CreateContext(bitmapContext));
	CleanupStack::PushL(bitmapContext);

	///////////////////////////////////////////////////////////////

	// Start Drawing
	_LIT(KUptimeTitle,"Uptime");
	// _LIT(KUptimeTitle,"StarTrek");

	// Draw Title Box and Title
	{
		bitmapContext->UseFont(iEikonEnv->TitleFont());

		TRect box(10,10,198,40);
		TInt baseline = box.Height() /2 + iEikonEnv->TitleFont()->AscentInPixels()/2;

		TInt margin=0; // left margin is ten pixels

		bitmapContext->SetBrushStyle(CGraphicsContext::ESolidBrush);
		bitmapContext->SetBrushColor(KRgbDarkGray);
		bitmapContext->SetPenColor(KRgbWhite);

		bitmapContext->DrawText(KUptimeTitle, box, baseline, CGraphicsContext::ECenter, margin);
	}


	// Draw Uptime
	{
		TBuf<30> startupTime;
		TBuf<10> days;
		TBuf<30> time;

		// Internal Flield Sperators
		_LIT(KIFS, " : ");
		_LIT(KIFS2, "/");
		_LIT(KIFS3, "   ");
		

		startupTime.Num(iModel->StartupTime().Day());
		startupTime.Append(KIFS2);
		startupTime.AppendNum(iModel->StartupTime().Month()+1);
		startupTime.Append(KIFS2);
		startupTime.AppendNum(iModel->StartupTime().Year());
		startupTime.Append(KIFS3);
		startupTime.AppendNum(iModel->StartupTime().Hour());
		startupTime.Append(KIFS);
		startupTime.AppendNum(iModel->StartupTime().Minute());
		startupTime.Append(KIFS);
		startupTime.AppendNum(iModel->StartupTime().Second());

		days.Num(iModel->Days());

		time.Num(iModel->Hours());
		time.Append(KIFS);
		time.AppendNum(iModel->Minutes());
		time.Append(KIFS);
		time.AppendNum(iModel->Seconds());

		_LIT(Kday, " day");
		_LIT(Kdays, " days");
		if (days.Mid(0).Match(_L("1")))
		{
			days.Append(Kdays);
		}
		else
		{
			days.Append(Kday);
		}


		TPoint pos;

		int x = 20;
		int y = 70;		

		pos.SetXY(x,y);
		_LIT(KStartupTime, "System Startup:");
		bitmapContext->UseFont(iEikonEnv->TitleFont());
		bitmapContext->SetPenColor(KRgbDarkGray);
		bitmapContext->DrawText(KStartupTime, pos);

		int height = 0;
		height = iEikonEnv->LegendFont()->HeightInPixels();

		y = y + height + 10;
		pos.SetXY(x,y);
		bitmapContext->UseFont(iEikonEnv->LegendFont());
		bitmapContext->SetPenColor(KRgbBlack);
		bitmapContext->DrawText(startupTime, pos);

		x = 20;
		y = y + height + 15;
		pos.SetXY(x,y);
		_LIT(KUptime, "Running for:");
		bitmapContext->UseFont(iEikonEnv->TitleFont());
		bitmapContext->SetPenColor(KRgbDarkGray);
		bitmapContext->DrawText(KUptime, pos);

		x = 20;
		y = y + height + 10;
		pos.SetXY(x,y);
		bitmapContext->UseFont(iEikonEnv->LegendFont());
		bitmapContext->SetPenColor(KRgbBlack);
		bitmapContext->DrawText(days, pos);

		int width = 0;
		width = iEikonEnv->LegendFont()->TextWidthInPixels(days);
		x = x + width + 10;
		pos.SetXY(x,y);
		bitmapContext->DrawText(time, pos);

		x = 20;
		y = y + height + 15;
		pos.SetXY(x,y);
		_LIT(KVersion, "System Version:");
		bitmapContext->UseFont(iEikonEnv->TitleFont());
		bitmapContext->SetPenColor(KRgbDarkGray);
		bitmapContext->DrawText(KVersion, pos);

		x = 20;
		y = y + height + 10;
		pos.SetXY(x,y);
		bitmapContext->UseFont(iEikonEnv->LegendFont());
		bitmapContext->SetPenColor(KRgbBlack);
		bitmapContext->DrawText(User::Version().Name(), pos);
	}
	// End Drawing

	////////////////////////////////////////////////////////////////////////
	//// Draw to real device
	CWindowGc& gc = SystemGc();
	gc.BitBlt(TPoint(0,0),offScreenBitmap);
	CleanupStack::PopAndDestroy(3);
}
