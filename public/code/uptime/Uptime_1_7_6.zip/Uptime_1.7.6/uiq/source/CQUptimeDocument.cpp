// CQUptimeDocument.cpp
//
// Copyright (c) 2003 Philipp Markus Alexander Schmid All rights reserved.
//

#include "CQUptimeDocument.h"


CQUptimeDocument::CQUptimeDocument(CEikApplication& aApp) : CQikDocument(aApp)
{
}


CQUptimeDocument* CQUptimeDocument::NewL(CEikApplication& aApp)
{
	CQUptimeDocument* self = new (ELeave) CQUptimeDocument(aApp);
	CleanupStack::PushL(self);
	self->ConstructL();
	CleanupStack::Pop();
	return self;
}


void CQUptimeDocument::ConstructL()
{
	iModel = CUptimeEngine::NewL();
}


CQUptimeDocument::~CQUptimeDocument()
{
	delete iModel;
}


CEikAppUi* CQUptimeDocument::CreateAppUiL()
{
	return new(ELeave) CQUptimeAppUi;
}