<?php

/** ensure this file is being included by a parent file */
defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );

require_once( $mainframe->getPath( 'front_html' ) );

switch ( $task ) {
	default:
		viewFiles();
		break;
}

function viewFiles() {
	global $mainframe, $mosConfig_absolute_path, $mosConfig_lang, $my;
	global $Itemid, $database, $_MAMBOTS;
	
	$gid = $my->gid;
	
	// Adds parameter handling
	if( $Itemid > 0 ) {
		$menu =& new mosMenu( $database );
		$menu->load( $Itemid );
		$params =& new mosParameters( $menu->params );
		$params->def( 'page_title', 1 );
		$params->def( 'pageclass_sfx', '' );
		$params->def( 'header', $menu->name, "Files" );
		$params->def( 'back_button', $mainframe->getCfg( 'back_button' ) );
	} else {
		$params =& new mosParameters('');
		$params->def( 'page_title', 1 );
		$params->def( 'pageclass_sfx', '' );
		$params->def( 'header', "Files" );
		$params->def( 'back_button', $mainframe->getCfg( 'back_button' ) );
	}
	
	$path = trim( mosGetParam( $_REQUEST, 'path', "" ) );

	// html output
	files_html::openhtml( $params );
	files_html::listfiles( $path );
}
?>
