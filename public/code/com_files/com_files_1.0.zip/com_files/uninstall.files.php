<?php

function com_uninstall()
{
	echo( "com_files has been successfully uninstalled." );
}

?>
