<?php
function com_install()
{
	global $mosConfig_live_site, $mosConfig_mailfrom;
	echo( "com_files has been successfully installed. You must complete the rest of the configuration manually." );
}

?>
