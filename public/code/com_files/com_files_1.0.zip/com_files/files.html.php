<?php

/** ensure this file is being included by a parent file */
defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );

class files_html {

	function format_filesize( $filesize )
	{
		$filesize = (int)$filesize;
		$units = array('B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB');
		$tot_units = (count($units) - 1);

		$pass = 0; // set zero, for Bytes
		while( $filesize >= 1024 && $pass < $tot_units )
		{
			$filesize /= 1024;
			$pass++;
		}

		return round($filesize, 2) .'&nbsp;'. $units[$pass];
	}
	
	function openhtml( $params ) {
		if ( $params->get( 'page_title' ) ) {
			?>
			<div class="componentheading<?php echo $params->get( 'pageclass_sfx' ); ?>">
			<?php echo $params->get( 'header' ); ?>
			</div> 
			<?php 
		}
	}
	
	function listfiles( $path ) {
		global $database;

		$component = new mosComponent( $database );
	        $component->load( $id );
	        $params =& new mosParameters( $component->params );

		// pull id of syndication component
		$query = "SELECT a.id"
		. "\n FROM #__components AS a"
		. "\n WHERE a.name = 'Files'";
		$database->setQuery( $query );
		$id = $database->loadResult();
		
		$component = new mosComponent( $database );
	        $component->load( $id );
	        $params =& new mosParameters( $component->params );

		$basedir = $params->def( 'path', '/var/www/files');
		$rbasedir = $params->def( 'rpath', '/files' );

		$path = strip_tags($path);
		$path = str_replace("..","",$path); // hack
		$path = rtrim($path, "/");

		if(!is_dir($basedir.$path))
		{
			echo "<p><b>Path:</b> <font color=\"#ff0000\">$path is unkown! Redirected to /</font></p>";
			$path="/";
		}
		else
		{
			if($path === "")
				echo "<p><b>Path:</b> /</p>";
			else
				echo "<p><b>Path:</b> ".$path."</p>";
		}

		?>
		
		<p>
		<table border="0">
		<tr>
			<td><img src="<?php echo "$mosConfig_live_site/components/com_files/images/blank.gif"; ?>" /></td>
			<td><b>Name</b></td><td width="20">&nbsp;</td>
			<td><b>Last modified</b></td><td width="20">&nbsp;</td>
			<td><b>Size</b></td>
		</tr>

		<?php

		$pos = strrpos($path, "/");
		if ($pos === false)
			$parent ="/";
		else
			$parent = substr($path, 0, $pos);

		$link = "index.php?option=com_files&path=".$parent;
		echo "<tr><td><img src=\"$mosConfig_live_site/components/com_files/images/back.gif\" /></td><td><a href=\"".sefRelToAbs($link)."\">Parent Directory</a></td><td width=\"20\">&nbsp;</td><td>&nbsp;</td><td width=\"20\">&nbsp;</td><td>&nbsp;</td></tr>\n";

		$dh  = opendir($basedir.$path);
		while (false !== ($filename = readdir($dh))) {
			$files[] = $filename;
		}
		sort($files);

		/* directories */
		foreach ($files as $file){
			if ($file != '.' && $file != '..') {

				$dat = date("Y-m-d\&\\n\b\s\p\;\&\\n\b\s\p\;\&\\n\b\s\p\;H:i:s", filemtime($basedir.$path."/".$file));
				if(is_dir($basedir.$path."/".$file))
				{
					$link = "index.php?option=com_files&path=".$path."/".$file;
					$image = "$mosConfig_live_site/components/com_files/images/folder.gif";
					$size = "-";
					if(strlen($file) > 35)
						$linktext = substr($file,0,32)."..>";
					else
						$linktext = $file;
					echo "<tr><td><img src=\"".$image."\" /></td><td><a href=\"".sefRelToAbs($link)."\">".$linktext."</a></td><td width=\"20\">&nbsp;</td><td>".$dat."</td><td width=\"20\">&nbsp;</td><td>$size</td></tr>\n";
				}
			}
		}
		/* files */
		foreach ($files as $file){
			if ($file != '.' && $file != '..') {

				$dat = date("Y-m-d\&\\n\b\s\p\;\&\\n\b\s\p\;\&\\n\b\s\p\;H:i:s", filemtime($basedir.$path."/".$file));
				if(!is_dir($basedir.$path."/".$file))
				{
					$link = $rbasedir.$path."/".$file;
					$image = "$mosConfig_live_site/components/com_files/images/file.gif";
					$size = files_html::format_filesize(filesize($basedir.$path."/".$file));
					if(strlen($file) > 35)
						$linktext = substr($file,0,32)."..>";
					else
						$linktext = $file;
					echo "<tr><td><img src=\"".$image."\" /></td><td><a href=\"".$link."\">".$linktext."</a></td><td width=\"20\">&nbsp;</td><td>".$dat."</td><td width=\"20\">&nbsp;</td><td>$size</td></tr>\n";
				}
			}
		}
		?>
		</table>
		</p>
		
		<?php
	}
}
?>

